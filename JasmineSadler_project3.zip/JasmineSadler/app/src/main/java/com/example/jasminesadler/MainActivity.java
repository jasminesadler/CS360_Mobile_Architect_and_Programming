package com.example.jasminesadler;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

@SuppressLint("MissingInflatedId")
public class MainActivity extends AppCompatActivity implements TextWatcher, MainActivity1 {
    public static int requestCode;
    private static final int PERMISSIONS_CODE = requestCode;
    EditText nameText;
    Button buttonSayHello;

    public MainActivity() {
    }
    private void askForPermission() {
        String[] permissions = new String[]{Manifest.permission.SEND_SMS};
        assert getActivity() != null;
        ActivityCompat.requestPermissions(getActivity(), permissions, PERMISSIONS_CODE);
    }

    private Activity getActivity() {
        return null;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSIONS_CODE) {
            for (int i = 0; i < permissions.length; i++) {
                String permission = permissions[i];
                int grantResult = grantResults[i];

                if (permission.equals(Manifest.permission.SEND_SMS)) {
                    if (grantResult == PackageManager.PERMISSION_GRANTED) {
                        onPPSButtonPress();
                    } else {
                        requestPermissions(new String[]{Manifest.permission.SEND_SMS}, PERMISSIONS_CODE);
                    }
                }
            }
        }
    }

    private void onPPSButtonPress() {
    }
            /*
             Permission granted. Send automated system notifications.
             Permission denied. App should still continue to function but no notifications will be sent.
            */

    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    public void afterTextChanged(Editable s) {
        buttonSayHello.setEnabled(!nameText.getText().toString().matches(""));
    }

    public void onRequestPermission(View view) {
    }


}
